package org.breaze;

public class Protocol {
    // Construye un mensaje CREATE_PATIENT simple
    public static String createPatientMessage(String fullName, String documentId, int age, String sex) {
        return "CREATE_PATIENT|full_name=" + sanitize(fullName)
                + "|document_id=" + sanitize(documentId)
                + "|age=" + age
                + "|sex=" + sanitize(sex);
    }

    // Evita caracteres que rompan el protocolo (muy simple)
    private static String sanitize(String s) {
        if (s == null) return "";
        return s.replace("|", " ").replace("=","");
 }

}
